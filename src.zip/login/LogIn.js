const Login = () => {



    return (
        <>
            ID: <input/>
            <br/>
            PW: <input/>
            <br/>
            <button >로그인</button>
        </>
    );
};

export default Login;
