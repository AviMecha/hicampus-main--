const AdminPage = () => {
    return (
        <>
        관리자
        </>
    );
};

export default AdminPage;
