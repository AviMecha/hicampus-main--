const Bottom = () => {
    return (
    <div>
    풋터
    </div>
    );
};

export default Bottom;
