const Board = () => {
    return (
        <>
        게시판
        </>
    );
};

export default Board;
